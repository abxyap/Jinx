from os import getcwd
from os.path import exists, expanduser
from shutil import copy2, copytree


def update_library_mk(path: str):
    print("Patching library.mk")

    with open(path, "r") as f:
        lines = f.readlines()
        
    # Jinx libraries should use tweak structure without a load command for Substrate
    # This is far from an elegant solution, but it works

    already_installed = False

    with open(path, "w") as f:
        for line in lines:
            if "JINX" in line and not already_installed:
                print("Jinx already installed, skipping library.mk patch")
                already_installed = True
        
            if line == "ifeq ($(LOCAL_INSTALL_PATH),)\n" and not already_installed:
                f.write("ifeq ($(USING_JINX), $(_THEOS_TRUE))\n")
                f.write("\tLOCAL_INSTALL_PATH = /Library/MobileSubstrate/DynamicLibraries\n")
                f.write("else ifeq ($(LOCAL_INSTALL_PATH),)\n")
            elif line == "$(eval $(call __mod,instance/library.mk))\n" and not already_installed:
                f.write("ifeq ($(USING_JINX), $(_THEOS_TRUE))\n")
                f.write("ifeq ($(call __exists,$(THEOS_CURRENT_INSTANCE).plist),$(_THEOS_TRUE))\n")
                f.write("\t$(ECHO_NOTHING)cp $(THEOS_CURRENT_INSTANCE).plist \"$(THEOS_STAGING_DIR)$(LOCAL_INSTALL_PATH)/\"$(ECHO_END)\n")
                f.write("endif\n")
                f.write("endif\n\n")
                f.write("$(eval $(call __mod,instance/library.mk))\n")
            else:
                f.write(line)


def move_templates(here: str, theos: str):
    print("Moving templates")
    
    # Add Jinx templates to the Theos templates directory

    copy2(here + "/iphone_tweak_swift_jinx.nic.tar", theos + "/templates/iphone_tweak_swift_jinx.nic.tar")
    copy2(here + "/iphone_tweak_swift_jinx_prefs.nic.tar", theos + "/templates/iphone_tweak_swift_jinx_prefs.nic.tar")
    
    # Say something once, why say it again?
    
    if not exists(theos + "/include/Jinx"):
        copytree(here + "/Jinx", theos + "/include/Jinx")
        
    if not exists(theos + "/include/AppSupport"):
        copytree(here + "/AppSupport", theos + "/include/AppSupport")


def main():
    here = getcwd()
    theos = expanduser("~") + "/theos"
    
    update_library_mk(theos + "/makefiles/instance/library.mk")
    move_templates(here, theos)
    
    print("Done")


if __name__ == "__main__":
    main()
